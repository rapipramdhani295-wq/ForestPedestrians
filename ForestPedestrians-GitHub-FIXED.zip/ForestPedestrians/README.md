# ForestPedestrians (prototype 0.1)

AML plugin source for GTA San Andreas Android, targeting arm64-v8a / Android 24.

## What this prototype does
- Uses the game's own civilian occupation chooser and population creation API.
- Requests a pedestrian with the native `makeWander` behavior, so the model and animations are from GTA SA.
- Attempts a conservative spawn point near the player using the game's ground-height query.
- Limits this first test to five plugin spawn attempts per session, one attempt every 12 seconds.

## Important limitation
This is a first in-game spawn/AI integration test, not yet a verified full-map forest walker. Native pedestrian wandering depends on GTA SA's pedestrian path network. In forest or empty terrain with no pedestrian path nodes, the game may fail to move the ped or may leave it idle. A separate waypoint/navigation implementation and obstacle checks are required to make reliable walking through off-network forest terrain. Ground-height lookup alone does not prove that a point is safe or walkable.

## Build
Push this repository to GitHub. The workflow in `.github/workflows/build.yml` builds `libForestPedestrians.so` with Android NDK r23c and uploads it as a workflow artifact.

## Install for testing
Copy the `.so` to the AML `mods` directory for the matching 64-bit game build. Test on a backed-up game installation. If the game crashes, remove the plugin and share the AML logcat/crash log before increasing spawn limits.
