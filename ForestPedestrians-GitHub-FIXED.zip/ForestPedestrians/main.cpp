#include <mod/amlmod.h>
#include <mod/logger.h>

#include <aml-psdk/game_sa/Events.h>
#include <aml-psdk/game_sa/entity/PlayerPed.h>
#include <aml-psdk/game_sa/other/Population.h>
#include <aml-psdk/game_sa/engine/World.h>
#include <aml-psdk/game_sa/base/Timer.h>

#include <cmath>
#include <cstdlib>

MYMOD(net.rapip.forestpedestrians, ForestPedestrians, 0.1, Rapip)

namespace
{
    // Conservative prototype limits. Increase only after testing on the phone.
    constexpr unsigned int SPAWN_INTERVAL_MS = 12000;
    constexpr int MAX_PLUGIN_SPAWNS_PER_SESSION = 5;
    constexpr float MIN_SPAWN_DISTANCE = 22.0f;
    constexpr float MAX_SPAWN_DISTANCE = 42.0f;

    unsigned int g_nextSpawnTime = 0;
    int g_spawnedThisSession = 0;

    float RandomRange(float minValue, float maxValue)
    {
        const float t = static_cast<float>(std::rand()) / static_cast<float>(RAND_MAX);
        return minValue + (maxValue - minValue) * t;
    }

    bool FindSpawnPosition(const CVector& playerPos, CVector& result)
    {
        // Try several positions around the player. Ground lookup avoids placing
        // a pedestrian at an arbitrary height, but does not by itself guarantee
        // that the point is clear of trees, rocks, water, or other obstacles.
        for (int attempt = 0; attempt < 8; ++attempt)
        {
            const float angle = RandomRange(0.0f, 6.2831853f);
            const float distance = RandomRange(MIN_SPAWN_DISTANCE, MAX_SPAWN_DISTANCE);
            const float x = playerPos.x + std::cos(angle) * distance;
            const float y = playerPos.y + std::sin(angle) * distance;
            const float groundZ = CWorld::FindGroundZForCoord(x, y);

            if (!std::isfinite(groundZ) || groundZ < -50.0f || groundZ > 1500.0f)
                continue;

            // Reject extreme height differences (cliffs / unrelated ground levels).
            if (std::fabs(groundZ - playerPos.z) > 18.0f)
                continue;

            result = CVector(x, y, groundZ + 0.15f);
            return true;
        }
        return false;
    }

    void TrySpawnPedestrian()
    {
        if (g_spawnedThisSession >= MAX_PLUGIN_SPAWNS_PER_SESSION)
            return;

        CPlayerPed* player = FindPlayerPed(0);
        if (!player || !player->IsAlive() || player->bInVehicle)
            return;

        const CVector playerPos = FindPlayerCoors(0);
        CVector spawnPos;
        if (!FindSpawnPosition(playerPos, spawnPos))
            return;

        // Ask the game's population system for a valid civilian model, then let
        // the game's own pedestrian creation/AI code initialize the character.
        char emptyAttractorName[1] = { '\0' };
        const int modelId = CPopulation::ChooseCivilianOccupation(
            true, true, 0, -1, 0, false, false, false, emptyAttractorName);

        if (modelId <= 0)
            return;

        CPed* ped = CPopulation::AddPed(PED_TYPE_CIVMALE,
                                        static_cast<unsigned int>(modelId),
                                        spawnPos,
                                        true); // native game wander behavior
        if (ped)
        {
            ++g_spawnedThisSession;
            logger->Info("Spawned native pedestrian %d/%d at %.1f %.1f %.1f",
                         g_spawnedThisSession, MAX_PLUGIN_SPAWNS_PER_SESSION,
                         spawnPos.x, spawnPos.y, spawnPos.z);
        }
    }
}

ON_MOD_LOAD()
{
    logger->SetTag("ForestPedestrians");
    std::srand(static_cast<unsigned int>(CTimer::GetTimeInMS()));
    logger->Info("ForestPedestrians 0.1 loaded (native pedestrian models/AI)");

    Events::gameProcessEvent += []()
    {
        const unsigned int now = CTimer::GetTimeInMS();
        if (now < g_nextSpawnTime)
            return;

        g_nextSpawnTime = now + SPAWN_INTERVAL_MS;
        TrySpawnPedestrian();
    };

    Events::restartGameEvent += []()
    {
        g_spawnedThisSession = 0;
        g_nextSpawnTime = 0;
    };
}
