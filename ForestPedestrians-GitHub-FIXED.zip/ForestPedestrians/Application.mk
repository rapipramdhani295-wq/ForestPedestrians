APP_STL := c++_static
APP_ABI := arm64-v8a
APP_PLATFORM := android-24
APP_OPTIM := release
NDK_TOOLCHAIN_VERSION := clang
